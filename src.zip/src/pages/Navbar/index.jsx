import React, { Component } from 'react';
import Navbar from '../../Components/Navbar';

export default class index extends Component {
  render() {
    return (
      <div>
        <Navbar />
      </div>
    );
  }
}
