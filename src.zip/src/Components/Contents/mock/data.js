
import Chair1 from "../../../assets/Prooducts/Chair3.png";  
import Chair3 from "../../../assets/section/Chair3.png";  
import Chair2 from "../../../assets/Prooducts/Chair1.png";  
import Divan from "../../../assets/section/Furniture1.png";

const Data = [Divan,Chair1,Chair2,Chair3];


export default Data;