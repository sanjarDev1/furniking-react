import React from 'react';
import Main from './pages/Main';
import './app.css';
const App = () => {
  return (
    <div>
      <Main />
    </div>
  );
};

export default App;
